CREATE PROCEDURE `LookByFName`(`AtFirstLetter` CHAR(1))
  BEGIN
     SELECT * FROM Employees  Where LEFT(FirstName, 1)=AtFirstLetter;

END