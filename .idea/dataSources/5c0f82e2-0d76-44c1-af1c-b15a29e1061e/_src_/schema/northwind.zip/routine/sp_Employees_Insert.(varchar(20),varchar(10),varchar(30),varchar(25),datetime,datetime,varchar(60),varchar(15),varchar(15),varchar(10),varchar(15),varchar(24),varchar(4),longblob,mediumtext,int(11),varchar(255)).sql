CREATE PROCEDURE `sp_Employees_Insert`(`AtLastName`        VARCHAR(20), `AtFirstName` VARCHAR(10),
                                       `AtTitle`           VARCHAR(30), `AtTitleOfCourtesy` VARCHAR(25),
                                       `AtBirthDate`       DATETIME, `AtHireDate` DATETIME, `AtAddress` VARCHAR(60),
                                       `AtCity`            VARCHAR(15), `AtRegion` VARCHAR(15),
                                       `AtPostalCode`      VARCHAR(10), `AtCountry` VARCHAR(15),
                                       `AtHomePhone`       VARCHAR(24), `AtExtension` VARCHAR(4), `AtPhoto` LONGBLOB,
                                       `AtNotes`           MEDIUMTEXT, `AtReportsTo` INT(11),
                                       `AtPhotoPath`       VARCHAR(255))
  BEGIN
Insert Into Employees Values(AtLastName,AtFirstName,AtTitle,AtTitleOfCourtesy,AtBirthDate,AtHireDate,AtAddress,AtCity,AtRegion,AtPostalCode,AtCountry,AtHomePhone,AtExtension,AtPhoto,AtNotes,AtReportsTo,AtPhotoPath);

	SELECT AtReturnID = LAST_INSERT_ID();
	
END