CREATE PROCEDURE `sp_Employees_Update`(`AtEmployeeID` INT(11), `AtLastName` VARCHAR(20), `AtFirstName` VARCHAR(10),
                                       `AtTitle`      VARCHAR(30), `AtTitleOfCourtesy` VARCHAR(25),
                                       `AtBirthDate`  DATETIME, `AtHireDate` DATETIME, `AtAddress` VARCHAR(60),
                                       `AtCity`       VARCHAR(15), `AtRegion` VARCHAR(15), `AtPostalCode` VARCHAR(10),
                                       `AtCountry`    VARCHAR(15), `AtHomePhone` VARCHAR(24), `AtExtension` VARCHAR(4),
                                       `AtPhoto`      LONGBLOB, `AtNotes` MEDIUMTEXT, `AtReportsTo` INT(11),
                                       `AtPhotoPath`  VARCHAR(255))
  BEGIN
Update Employees
	Set
		LastName = AtLastName,
		FirstName = AtFirstName,
		Title = AtTitle,
		TitleOfCourtesy = AtTitleOfCourtesy,
		BirthDate = AtBirthDate,
		HireDate = AtHireDate,
		Address = AtAddress,
		City = AtCity,
		Region = AtRegion,
		PostalCode = AtPostalCode,
		Country = AtCountry,
		HomePhone = AtHomePhone,
		Extension = AtExtension,
		Photo = AtPhoto,
		Notes = AtNotes,
		ReportsTo = AtReportsTo,
    PhotoPath = AtPhotoPath
	Where
		EmployeeID = AtEmployeeID;

END