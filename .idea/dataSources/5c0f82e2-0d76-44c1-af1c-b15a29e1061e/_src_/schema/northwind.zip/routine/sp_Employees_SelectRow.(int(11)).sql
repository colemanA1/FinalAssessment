CREATE PROCEDURE `sp_Employees_SelectRow`(`AtEmployeeID` INT(11))
  BEGIN
SELECT * FROM Employees Where EmployeeID = AtEmployeeID;

END