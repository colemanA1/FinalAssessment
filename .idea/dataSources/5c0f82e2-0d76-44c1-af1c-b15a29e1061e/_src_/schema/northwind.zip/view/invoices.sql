CREATE VIEW `invoices` AS
