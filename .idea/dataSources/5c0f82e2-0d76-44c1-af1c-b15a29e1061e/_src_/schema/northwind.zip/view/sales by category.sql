CREATE VIEW `sales by category` AS
